import React from 'react'

const Home = () => {
  return (
    <>
    <div className='min-h-screen bg-gradient-to-br from-red-900 to-gray-950'>
    
    <header className='relative top-0 bg-gray-950 mb-10'>
			<ul className='flex items-center justify-center gap-20 py-4 md:gap-25 lg:gap-30 xl:gap-40'>
				<li>
					<a href="#" className='text-red-600 text-xl font-normal hover:font-semibold md:text-2xl lg:text-3xl xl:text-4xl'>Home</a>
				</li>
				<li>
					<a href="#" className='text-red-600 text-xl font-normal hover:font-semibold md:text-2xl lg:text-3xl xl:text-4xl'>Packages</a>
				</li>
				<li>
					<a href="#" className='text-red-600 text-xl font-normal hover:font-semibold md:text-2xl lg:text-3xl xl:text-4xl'>Travels</a>
				</li>
			</ul>
	</header>

    <div className='flex flex-col items-center justify-center mt-20'>
	<h1 className='text-4xl py-5 text-center text-white md:text-5xl lg:text-5xl xl:text-6xl'>Tourism Website</h1>
	<p className='text-2xl w-3/5 text-center pb-20 text-white sm:w-4/5 md:text-3xl lg:text-3xl xl:text-4xl'>This my taiwind exercise just for showcase!</p>
  <div className='grid grid-cols-1 grid-rows-2 gap-8 min-md:grid-cols-2 min-md:grid-rows-2'>
	  <img className='py-5 hover:scale-110 transition ease-in-out duration-300 h-[300px] w-[300px]' src="https://img.freepik.com/free-photo/beautiful-wide-shot-chicago-river-with-amazing-modern-architecture_181624-3897.jpg?t=st=1745664644~exp=1745668244~hmac=8f5e04e65bc9949554cf283a9b4c04cebee975e74f5a26ceee48c4e0ccb87e81&w=1380"></img>
    <img className='py-5 hover:scale-110 transition ease-in-out duration-300 h-[300px] w-[300px]' src="https://img.freepik.com/premium-photo/view-city-waterfront-sunset_1048944-5424663.jpg?w=1380"></img>
    <img className='py-5 hover:scale-110 transition ease-in-out duration-300 h-[300px] w-[300px]' src="https://img.freepik.com/premium-photo/chicago-river-chicago-illinois_538646-7185.jpg?uid=R114690421&ga=GA1.1.1177804076.1738222206&semt=ais_hybrid&w=740"></img>
    <img className='py-5 hover:scale-110 transition ease-in-out duration-300 h-[300px] w-[300px]' src="https://img.freepik.com/premium-photo/green-chicago-river-bridge-river-by-buildings-against-sky-city_1048944-22628301.jpg?uid=R114690421&ga=GA1.1.1177804076.1738222206&semt=ais_hybrid&w=740"></img>
  </div>
</div>
    <footer className='bg-red-600 flex items-center justify-center mt-20 py-5 bottom-0 relative'>
        <time className='text-md font-medium text-white'>April 22, 2025</time>
    </footer>
        
    </div>
    </>
  )
}

export default Home
